#include<stdio.h>
#include<string.h>
#include<iostream>
#include<algorithm>
using namespace std;
const int MAXN =(int)1e6+10;
int wa[MAXN],wb[MAXN],wv[MAXN],we[MAXN],rk[MAXN];
int cmp(int *r,int a,int b,int l){return r[a]==r[b]&&r[a+l]==r[b+l];}
void build_sa(int *r,int *sa,int n,int m){
	int i,j,p,*x=wa,*y=wb,*t;
	for(i=0;i<m;i++)we[i]=0;
	for(i=0;i<n;i++)we[x[i]=r[i]]++;
	for(i=1;i<m;i++)we[i]+=we[i-1];
	for(i=n-1;i>=0;i--)sa[--we[x[i]]]=i;
	for(j=1,p=1;p<n;j*=2,m=p){
		for(p=0,i=n-j;i<n;i++)y[p++]=i;
		for(i=0;i<n;i++)if(sa[i]>=j)y[p++]=sa[i]-j;
		for(i=0;i<n;i++)wv[i]=x[y[i]];
		for(i=0;i<m;i++)we[i]=0;
		for(i=0;i<n;i++)we[wv[i]]++;
		for(i=1;i<m;i++)we[i]+=we[i-1];
		for(i=n-1;i>=0;i--)sa[--we[wv[i]]]=y[i];
		for(t=x,x=y,y=t,p=1,x[sa[0]]=0,i=1;i<n;i++)
		x[sa[i]]=cmp(y,sa[i-1],sa[i],j)?p-1:p++;
	}
}
int height[MAXN];
void calheight(int *r,int *sa,int n){
	int i,j,k=0;
	for(i=1;i<=n;i++)rk[sa[i]]=i;
	for(i=0;i<n;height[rk[i++]]=k){
		for(k?k--:0,j=sa[rk[i]-1];r[i+k]==r[j+k];k++);
	}
}
int sa[MAXN],a[MAXN];
char str[MAXN];
int main()
{
	scanf("%s",str);
	int n=strlen(str);
	for(int i=0;i<n;i++)a[i]=str[i];
	a[n]=0;
	build_sa(a,sa,n+1,128);
	calheight(a,sa,n);
	for(int i=1;i<=n;i++)printf("%d ",sa[i]+1);
	printf("\n");
	for(int i=2;i<=n;i++)printf("%d ",height[i]);
	printf("\n");
	return 0;
}